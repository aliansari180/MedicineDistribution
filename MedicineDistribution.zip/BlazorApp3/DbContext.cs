﻿// DbContext.cs
using BlazorApp3.Models;
using Microsoft.EntityFrameworkCore;

using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

public class MedicineDbContext : IdentityDbContext<ApplicationUser>
{
    public MedicineDbContext(DbContextOptions<MedicineDbContext> options) : base(options)
    {
    }

    // Your existing DbSet properties
    public DbSet<Medicine> Medicines { get; set; }
    public DbSet<Distributor> Distributors { get; set; }
    public DbSet<PharmaceuticalCompany> PharmaceuticalCompanies { get; set; }
    public DbSet<Order> Orders { get; set; }
    public DbSet<Shop> Shops { get; set; }
    public DbSet<ShopOrder> ShopOrders { get; set; }
}
