﻿using BlazorApp3.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

public class MedicineService
{
    private readonly MedicineDbContext _context;

    public MedicineService(MedicineDbContext context)
    {
        _context = context;
    }

    public List<Medicine> GetAllMedicines()
    {
        return _context.Medicines.ToList();
    }

    public void AddMedicine(Medicine medicine, int pharmaceuticalCompanyId)
    {
        medicine.PharmaceuticalCompanyId = pharmaceuticalCompanyId;
        _context.Medicines.Add(medicine);
        _context.SaveChanges();
    }


    public Medicine GetMedicineById(int id)
    {
        return _context.Medicines.Find(id);
    }

    public void UpdateMedicine(Medicine updatedMedicine)
    {
        var existingMedicine = _context.Medicines.Find(updatedMedicine.MedicineId);
        if (existingMedicine != null)
        {
            existingMedicine.Name = updatedMedicine.Name;
            // Update other properties as needed
            _context.SaveChanges();
        }
    }

    public void DeleteMedicine(int id)
    {
        var medicineToDelete = _context.Medicines.Find(id);
        if (medicineToDelete != null)
        {
            _context.Medicines.Remove(medicineToDelete);
            _context.SaveChanges();
        }
    }

    public List<PharmaceuticalCompany> GetAllPharmaceuticalCompanies()
    {
        return _context.PharmaceuticalCompanies.ToList();
    }

    public void AddPharmaceuticalCompany(PharmaceuticalCompany company)
    {
        _context.PharmaceuticalCompanies.Add(company);
        _context.SaveChanges();
    }

    public void ApproveMedicine(int medicineId)
    {
        var medicine = _context.Medicines.Find(medicineId);
        if (medicine != null)
        {
            medicine.IsApproved = true;
            _context.SaveChanges();
        }
    }

    public void RejectMedicine(int medicineId)
    {
        var medicine = _context.Medicines.Find(medicineId);
        if (medicine != null)
        {
            _context.Medicines.Remove(medicine);
            _context.SaveChanges();
        }
    }

    public List<Distributor> GetAllDistributors()
    {
        return _context.Distributors.ToList();
    }

    public void AddDistributor(Distributor distributor)
    {
        _context.Distributors.Add(distributor);
        _context.SaveChanges();
    }

    public List<Order> GetAllOrders()
    {
        return _context.Orders.ToList();
    }

    public void PlaceOrder(Order order)
    {
        if (order != null && order.Quantity > 0)
        {
            order.OrderDate = DateTime.Now;
            order.Status = "Pending"; // Set the initial status to "Pending"

            _context.Orders.Add(order);
            _context.SaveChanges();
        }
    }

    public void ProcessOrder(int orderId)
    {
        var order = _context.Orders.Find(orderId);

        if (order != null && order.Status == "Pending")
        {
            // Update medicine inventory
            var medicine = _context.Medicines.Find(order.MedicineId);
            if (medicine != null)
            {
                if (medicine.QuantityAvailable >= order.Quantity)
                {
                    medicine.QuantityAvailable -= order.Quantity;
                    // Add additional logic or events related to order processing

                    // Set order status to "Processed"
                    order.Status = "Processed";
                    _context.SaveChanges();
                }

            }

        }
    }
    public void DeliveredOrder(int orderId)
    {
        var order = _context.Orders.Find(orderId);

        if (order != null && order.Status == "Pending")
        {
            // Update medicine inventory
            var medicine = _context.Medicines.Find(order.MedicineId);
            if (medicine != null)
            {
                // Add additional logic or events related to order processing

                // Set order status to "Delivered"
                order.Status = "Delivered";
                _context.SaveChanges();
            }
        }
    }


    public void UpdateOrderStatus(int orderId, string newStatus)
    {
        var order = _context.Orders.FirstOrDefault(o => o.OrderId == orderId);

        if (order != null)
        {
            order.Status = newStatus;
            _context.SaveChanges();
        }
    }

    public void DeleteOrder(int orderId)
    {
        var order = _context.Orders.Find(orderId);
        if (order != null)
        {
            _context.Orders.Remove(order);
            _context.SaveChanges();
        }
    }
    public List<Shop> GetAllShops()
    {
        return _context.Shops.ToList();
    }

    public void RegisterShop(Shop shop)
    {
        _context.Shops.Add(shop);
        _context.SaveChanges();
    }

    public List<ShopOrder> GetAllShopOrders()
    {
        return _context.ShopOrders.Include(o => o.Shop).Include(o => o.Medicine).ToList();
    }

    public void PlaceShopOrder(ShopOrder shopOrder)
    {
        if (shopOrder != null && shopOrder.Quantity > 0)
        {
            shopOrder.OrderDate = DateTime.Now;
            shopOrder.Status = "Pending"; // Set the initial status to "Pending"

            _context.ShopOrders.Add(shopOrder);
            _context.SaveChanges();
        }
    }


  

    public void UpdateShopOrderStatus(int shopOrderId, string newStatus)
    {
        var shopOrder = _context.ShopOrders.FirstOrDefault(o => o.ShopOrderId == shopOrderId);

        if (shopOrder != null)
        {
            shopOrder.Status = newStatus;
            _context.SaveChanges();
        }
    }

    public void DeleteShopOrder(int shopOrderId)
    {
        var shopOrder = _context.ShopOrders.Find(shopOrderId);
        if (shopOrder != null)
        {
            _context.ShopOrders.Remove(shopOrder);
            _context.SaveChanges();
        }
    }



    public void ProcessShopOrder(int shopOrderId)
    {
        var shopOrder = _context.ShopOrders.Find(shopOrderId);

        if (shopOrder != null && shopOrder.Status == "Pending")
        {
            // Update medicine inventory
            var medicine = _context.Medicines.Find(shopOrder.MedicineId);
            if (medicine != null)
            {
                if (medicine.QuantityAvailable >= shopOrder.Quantity)
                {
                    medicine.QuantityAvailable -= shopOrder.Quantity;

                    // Set shop order status to "Processed"
                    shopOrder.Status = "Processed";
                    _context.SaveChanges();
                }
            }
        }
    }





}


