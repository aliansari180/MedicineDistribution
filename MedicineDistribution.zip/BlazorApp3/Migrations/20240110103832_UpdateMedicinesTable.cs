﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BlazorApp3.Migrations
{
    public partial class UpdateMedicinesTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Medicines_PharmaceuticalCompanies_PharmaceuticalCompanyId",
                table: "Medicines");

            migrationBuilder.DropIndex(
                name: "IX_Medicines_PharmaceuticalCompanyId",
                table: "Medicines");

            migrationBuilder.RenameColumn(
                name: "PharmaceuticalCompanyId",
                table: "Medicines",
                newName: "QuantityAvailable");

            migrationBuilder.AddColumn<string>(
                name: "Description",
                table: "Medicines",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<DateTime>(
                name: "ExpiryDate",
                table: "Medicines",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ManufacturingDate",
                table: "Medicines",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Description",
                table: "Medicines");

            migrationBuilder.DropColumn(
                name: "ExpiryDate",
                table: "Medicines");

            migrationBuilder.DropColumn(
                name: "ManufacturingDate",
                table: "Medicines");

            migrationBuilder.RenameColumn(
                name: "QuantityAvailable",
                table: "Medicines",
                newName: "PharmaceuticalCompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_Medicines_PharmaceuticalCompanyId",
                table: "Medicines",
                column: "PharmaceuticalCompanyId");

            migrationBuilder.AddForeignKey(
                name: "FK_Medicines_PharmaceuticalCompanies_PharmaceuticalCompanyId",
                table: "Medicines",
                column: "PharmaceuticalCompanyId",
                principalTable: "PharmaceuticalCompanies",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
