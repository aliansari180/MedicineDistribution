﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BlazorApp3.Migrations
{
    public partial class UpdateModels : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Address",
                table: "PharmaceuticalCompanies",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "PharmaceuticalCompanyId",
                table: "Medicines",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Medicines_PharmaceuticalCompanyId",
                table: "Medicines",
                column: "PharmaceuticalCompanyId");

            migrationBuilder.AddForeignKey(
                name: "FK_Medicines_PharmaceuticalCompanies_PharmaceuticalCompanyId",
                table: "Medicines",
                column: "PharmaceuticalCompanyId",
                principalTable: "PharmaceuticalCompanies",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Medicines_PharmaceuticalCompanies_PharmaceuticalCompanyId",
                table: "Medicines");

            migrationBuilder.DropIndex(
                name: "IX_Medicines_PharmaceuticalCompanyId",
                table: "Medicines");

            migrationBuilder.DropColumn(
                name: "Address",
                table: "PharmaceuticalCompanies");

            migrationBuilder.DropColumn(
                name: "PharmaceuticalCompanyId",
                table: "Medicines");
        }
    }
}
