﻿namespace BlazorApp3.Models
{
    using Microsoft.AspNetCore.Identity;

    public class ApplicationUser : IdentityUser
    {
        // Additional properties or methods if needed
    }

}
