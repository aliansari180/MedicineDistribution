﻿namespace BlazorApp3.Models
{
    public class Distributor
    {
        public int Id { get; set; }
        public string CompanyName { get; set; }
        public string ContactInformation { get; set; }
        public string Address { get; set; }
    }

}
