﻿using BlazorApp3.Models;

public class Medicine
{
    public int MedicineId { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
    public DateTime ManufacturingDate { get; set; }
    public DateTime ExpiryDate { get; set; }
    public int QuantityAvailable { get; set; }
    public bool IsApproved { get; set; } = false;

    // Foreign key
    public int PharmaceuticalCompanyId { get; set; }
    public PharmaceuticalCompany PharmaceuticalCompany { get; set; }
}
