﻿// BlazorApp3/Models/Order.cs
using System;

namespace BlazorApp3.Models
{
    public class Order
    {
        public int OrderId { get; set; }
        public int DistributorId { get; set; }
        public int MedicineId { get; set; }
        public int Quantity { get; set; }
        public DateTime OrderDate { get; set; }
        public string Status { get; set; } 

        // Navigation properties
        public Distributor Distributor { get; set; }
        public Medicine Medicine { get; set; }
    }

}
