﻿public class PharmaceuticalCompany
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string ContactDetails { get; set; }
    public string Address { get; set; }

    // Navigation property
    public List<Medicine> Medicines { get; set; } = new List<Medicine>();
}
