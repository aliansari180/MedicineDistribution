﻿// Shop.cs
namespace BlazorApp3.Models
{
    public class Shop
    {
        public int ShopId { get; set; }
        public string ShopName { get; set; }
        public string ContactInformation { get; set; }
        public string Address { get; set; }

        // Navigation property
        public List<ShopOrder> Orders { get; set; } = new List<ShopOrder>();
    }
}