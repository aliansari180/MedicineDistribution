﻿// ShopOrder.cs
namespace BlazorApp3.Models
{
    public class ShopOrder
    {
        public int ShopOrderId { get; set; }
        public int ShopId { get; set; }
        public int MedicineId { get; set; }
        public int Quantity { get; set; }
        public DateTime OrderDate { get; set; }
        public string Status { get; set; }

        // Navigation properties
        public Shop Shop { get; set; }
        public Medicine Medicine { get; set; }
    }
}